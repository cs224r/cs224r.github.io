"""
setup.py (READ-ONLY)
"""
from setuptools import setup

setup(
    name='cs224r',
    version='0.1.0',
    packages=['cs224r'],
)
